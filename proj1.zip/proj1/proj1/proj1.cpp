#include <iostream>
#include <string>
using namespace std;

float gprob,gcost,gB_prob0,gB_prob1;
float gB_cost0,gB_cost1;
float Dtemp[2][7][32];


//return single Rbuf element
float Rval(float Rbuf[1][2][2]){
	float prob=0.0; 
    float cost=0;
	if((Rbuf[0][0][0]==0.0) & (Rbuf[0][1][0]==0.0)){
		prob=0.0;
		cost=0;
	}
	else{
	if(Rbuf[0][0][0]==0.0){
		prob=Rbuf[0][1][0];
		cost=Rbuf[0][1][1];
	}
	else if(Rbuf[0][1][0]==0.0){
		prob=Rbuf[0][0][0];
		cost=Rbuf[0][0][1];
	}
	else{
		prob=Rbuf[0][0][0] + Rbuf[0][1][0];
		cost=Rbuf[0][1][1];
	}
	}
	/*
	cout<<"Inside Rval"<<endl;
	cout<<"prob: "<<prob<<",";
	cout<<"cost: "<<cost<<endl;
	*/
	gprob=prob;
	gcost=cost;
	return (prob,cost);
	
} 


//get Rbuf [--][--] within given timing constraint 
float Resbuf(int i, int time_const,float arr[8][2][3]){
	int time;
	float prob; 
    float cost;
	float Rbuf[1][2][2];
	int l=0;
	int j=0;
	for(int r1=0; r1<2; r1++){
		time=int(arr[i][j][0]);
		if(time <=time_const){
			prob=arr[i][j][1];
			cost=arr[i][j][2];
			Rbuf[0][l][0]=prob;
			Rbuf[0][l][1]=cost;
		
		}
		else{
			Rbuf[0][l][0]=0.0;
			Rbuf[0][l][1]=0;
		}
		l++;
	
		j++;
	}
	
	/*
	cout<<"Inside rsbuf before rval"<<endl;
	cout<<Rbuf[0][0][0]<<",";
	cout<<Rbuf[0][0][1]<<endl;
	cout<<Rbuf[0][1][0]<<",";
	cout<<Rbuf[0][1][1]<<endl;
	*/
	(prob,cost)=Rval(Rbuf);
	/*
	cout<<"Inside Rsbuf after rval"<<endl;
	cout<<"prob: "<<prob<<",";
	cout<<"cost: "<<cost<<endl;
	*/
	//gprob=prob;
	//gcost=cost;
	
	return(prob,cost);
	

}


//compare r1 and r2 for b_table
float R1andR2_cmp(float R1_prob, float R2_prob, int R1_cost, int R2_cost){

	float B_prob0,B_prob1; 
	int B_cost0,B_cost1;
	if(R1_prob==1.0 && R2_prob==1.0){
		B_prob0=1.0;
		if(R1_cost > R2_cost){
			B_cost0= R2_cost;
		}
		else{
			B_cost0=R1_cost;
		}
		B_prob1=0;
		B_cost1=0;
	}

	else{
		B_prob0=R1_prob;
		B_cost0=R1_cost;
		B_prob1=R2_prob;
		B_cost1=R2_cost;
	}
	/*
	cout<<"Inside B thingi"<<endl;
	cout<<"B_prob0: "<<B_prob0<<endl;
	cout<<"B_cost0: "<<B_cost0<<endl;
	cout<<"B_prob1: "<<B_prob1<<endl;
	cout<<"B_cost1: "<<B_cost1<<endl;
	*/
	gB_prob0=B_prob0;
	gB_prob1=B_prob1;
	gB_cost0=B_cost0;
	gB_cost1=B_cost1;
	return (B_prob0,B_prob1,B_cost0,B_cost1);

}


void Dval(float NarrB[3][7][8],int node1, int node2, int p1, int p2,int Dnode,int Dtime, int t_deb){
	

	float prob1,prob2;
	int cost1,cost2;
	//float Dtemp[2][7][32]; //Assuming each node has 4 sets so two nodes will give 16 sets and each set has 2!!
	int Dindex=0;
	float prob;
	int cost;
	t_deb=0;
	if(t_deb==2){
		cout<<"=====Debug============="<<endl;
		cout<<"P1: "<<p1<<endl;
		cout<<NarrB[node1][p1-1][0]<<",";
		cout<<NarrB[node1][p1-1][1]<<"-";
		cout<<NarrB[node1][p1-1][2]<<",";
		cout<<NarrB[node1][p1-1][3]<<endl;

		cout<<"P2: "<<p2<<endl;
		cout<<NarrB[node2][p2-1][0]<<",";
		cout<<NarrB[node2][p2-1][1]<<"-";
		cout<<NarrB[node2][p2-1][2]<<",";
		cout<<NarrB[node2][p2-1][3]<<endl;
	}
	
	for(int k=0; k < 8; k=k+2){  //for loop for Node1

		prob1=NarrB[node1][p1-1][k];
		cost1=NarrB[node1][p1-1][k+1];
		if(t_deb==2){
			if(prob1!=0){
				cout<<"P1 at: "<<k<<endl;
				cout<<"("<<prob1<<","<<cost1<<")"<<endl;
			}
		}

		if(prob1){
		for(int l=0; l<8; l=l+2){ //for loop for Node2
			prob2=NarrB[node2][p2-1][l];
			cost2=NarrB[node2][p2-1][l+1];
			
			if(prob2){
			if(t_deb==2){
				if(prob2!=0){
					cout<<"P2 at: "<<l<<endl;
					cout<<"("<<prob2<<","<<cost2<<")"<<endl;
				}
			}
			
			prob=prob1*prob2;
			cost=cost1+cost2;

			if(t_deb==2){
				if(prob!=0){
					cout<<"After calculation(prob,cost): "<<"("<<prob<<","<<cost<<")"<<endl;
			
				}
			}

			//Dtemp[Dnode][Dtime][Dindex]=prob;
			
			if(prob==0.0){
				//Dtemp[Dnode][Dtime][Dindex+1]=0;
				
			}
			else{
				Dtemp[Dnode][Dtime][Dindex]=prob;
				Dtemp[Dnode][Dtime][Dindex+1]=cost;
				
			}
			Dindex=Dindex+2;
			}
		}
		}
	}
	/*
	if(t_deb==2){
		cout<<"Dtemp-----"<<endl;
		for(int i=0; i < 32; i++){
		cout<<Dtemp[0][0][i]<<",";
		}
	}
	*/
	//return (Dtemp);
}


bool checker(float prob1, int cost1, float prob2, int cost2){
	if(prob1>prob2){
		return true;
	}
	else if((prob1==prob2) & (cost1>=cost2)){
		return false;
	}
	else if((prob1 < prob2) & (cost1 >= cost2)){
		return false;
	}
	else{
		return true;
	}

}



float main(){
					 //R1: (T,P,C) , (T,P,C)                
	                 //R2: (T,P,C) , (T,P,C)
	float arr[8][2][3]={ {{1,0.8,9},{2,0.2,9 }}, 
			           { {2,0.8,5} ,{3,0.2,5}},

					   { {1,0.9,10},{3,0.1,10}},
					   { {2,0.7,4}, {4,0.3,4}},

					   { {1,0.9,9},{4,0.1,9}},
					   { {2,0.8,5},{6,0.2,5}},

					   { {1,0.2,8},{2,0.8,8}},
					   { {3,0.4,2},{6,0.6,2}}
	};

	cout<<"Initial Table: "<<endl;
	cout<<"     "<<"R1    "<<"   R2   "<<endl;
	int node=0, print_node=2;

	for (int i=0; i<8;i++){
		if(print_node==2){
			cout<<endl<<"Node "<<node<<endl;
			node=node+1;
			print_node=0;
		}
		for(int j=0;j<2;j++){
			for(int k=0;k<3;k++){
				cout<<arr[i][j][k]<<",";
			}
			cout<<" | ";
		}
		cout<<endl;
		print_node++;	
	}

	cout<<"=================================="<<endl;
	cout<<endl<<"B TABLE: "<<endl;

	//int buf[2][2];
	float arrB[4][7][4];
	//int R1buf[2], R2buf[2];
	int i=0;
	float prob0=0.0;
	float prob1=0.0;
	float cost0=0,cost1=0;
	 
	/*
	(prob0,cost0)=Resbuf(i,6,arr);
	prob0=gprob;
	cost0=gcost;
	if(prob0<=0){
		prob1=0;
		cost1=0;
	}
	i=i+1;
	(prob1,cost1)=Resbuf(i,6,arr);
	prob1=gprob;
	cost1=gcost;
	if(prob1<=0){
		prob1=0;
		cost1=0;
	}

	
	cout<<"======================="<<endl;
	
	cout<<"prob0: "<<prob0<<",";
	cout<<"cost0: "<<cost0<<endl;
	cout<<"prob1: "<<prob1<<",";
	cout<<"cost1: "<<cost1<<endl;
	
	(prob0,prob1,cost0,cost1)=R1andR2_cmp(prob0,prob1,cost0,cost1);
	prob0=gB_prob0;
	prob1=gB_prob1;
	cost0=gB_cost0;
	cost1=gB_cost1;
	cout<<"--------------------------"<<endl;
	cout<<"prob0: "<<prob0<<endl;
	cout<<"cost0: "<<cost0<<endl;
	cout<<"prob1: "<<prob1<<endl;
	cout<<"cost1: "<<cost1<<endl;
	*/

	cout<<" T=1 "<<"          T=2 "<<"          T=3 "<<"         T=4 "<<"         T=5 "<<"       T=6 "<<endl;
	for(int node=0; node<4; node++){
		cout<<"Node"<<node<<endl;
		gprob=0;
		gcost=0;
		gB_prob0=0;
		gB_prob1=0;
		gB_cost0=0;
		gB_cost1=0;

		for(int time_const=1; time_const < 7; time_const++){
			(prob0,cost0)=Resbuf(i,time_const,arr);
			prob0=gprob;
			cost0=gcost;
			if(prob0<=0){
				prob0=0;
				cost0=0;
			}
			i=i+1;
			(prob1,cost1)=Resbuf(i,time_const,arr);
			prob1=gprob;
			cost1=gcost;
			if(prob1<=0){
				prob1=0;
				cost1=0;
			}
			i=i-1;
			(prob0,prob1,cost0,cost1)=R1andR2_cmp(prob0,prob1,cost0,cost1);
			prob0=gB_prob0;
			prob1=gB_prob1;
			cost0=gB_cost0;
			cost1=gB_cost1;
			arrB[node][time_const-1][0]=prob0;
			arrB[node][time_const-1][1]=int(cost0);
			arrB[node][time_const-1][2]=prob1;
			arrB[node][time_const-1][3]=int(cost1);
		
			//cout<<"("<<prob0<<","<<cost0<<")"<<"("<<prob1<<","<<cost1<<")"<<" | ";
			cout<<"(";
			
			if(arrB[node][time_const-1][0]==0){
				cout<<arrB[node][time_const-1][2]<<","<<arrB[node][time_const-1][3]<<")"<<"    "<<"|";
			}
			else if(arrB[node][time_const-1][2]==0){
				cout<<arrB[node][time_const-1][0]<<","<<arrB[node][time_const-1][1]<<")"<<"    "<<"|";
			}
			else{
			
				printf("%0.1f,%i)(%0.1f,%i)|",arrB[node][time_const-1][0],int(arrB[node][time_const-1][1]),arrB[node][time_const-1][2],int(arrB[node][time_const-1][3]));
				//cout<<arrB[node][time_const-1][0]<<" ,"<<arrB[node][time_const-1][1]<<")"<<"("<<arrB[node][time_const-1][2]<<","<<arrB[node][time_const-1][3]<<")"<<"|";
			}
		}
		i=i+2;
		cout<<endl;
	}
	
	//New B table after merging node 2 and 3-----------------------------
	int a=2; //Start from Node2
	float NarrB[3][7][8];
	
	/*
	cout<<"========Debug node 2 and node 3 merge==============="<<endl;
	NarrB[0][0][0]= arrB[2][0][0] * arrB[3][0][0];
	NarrB[0][0][1]= arrB[2][0][1] + arrB[3][0][1];

	printf("%4.2f,%i)|",NarrB[0][0][0],int(NarrB[0][0][1]));
	*/

	if(1){
    int a=2;
	for(int i=0; i < 7; i++){
	for(int time_const=1; time_const<7;time_const++){
				//Read Node2			
				NarrB[a][time_const-1][0]= arrB[a][time_const-1][0] * arrB[a+1][time_const-1][0];
				if(NarrB[a][time_const-1][0]==0){
					NarrB[a][time_const-1][1]=0;
				}
				else{
					NarrB[a][time_const-1][1]= arrB[a][time_const-1][1] + arrB[a+1][time_const-1][1];
				}

				NarrB[a][time_const-1][2]= arrB[a][time_const-1][0] * arrB[a+1][time_const-1][2];
				if(NarrB[a][time_const-1][2]==0){
					NarrB[a][time_const-1][3]=0;
				}
				else{
					NarrB[a][time_const-1][3]= arrB[a][time_const-1][1] + arrB[a+1][time_const-1][3];
				}

				NarrB[a][time_const-1][4]= arrB[a][time_const-1][2] * arrB[a+1][time_const-1][0];
				if(NarrB[0][time_const-1][4]==0){
					NarrB[0][time_const-1][5]=0;
				}
				else{
					NarrB[a][time_const-1][5]= arrB[a][time_const-1][3] + arrB[a+1][time_const-1][1];
				}

				NarrB[a][time_const-1][6]= arrB[a][time_const-1][2] * arrB[a+1][time_const-1][2];
				if(NarrB[a][time_const-1][6]==0){
					NarrB[a][time_const-1][7]=0;
				}
				else {
					NarrB[a][time_const-1][7]= arrB[a][time_const-1][3] + arrB[a+1][time_const-1][3];
				}
				
	}

	}

	   //copy old B table to new B table (only node 0 and and node1-----------------------------
	   for(int i=0; i < 2; i++){
		   for(int j=1; j<7; j++){

            if(arrB[i][j-1][0]!=0){
				NarrB[i][j-1][0]=arrB[i][j-1][0];
				NarrB[i][j-1][1]=arrB[i][j-1][1];
			}
			else{
				NarrB[i][j-1][0]=0;
				NarrB[i][j-1][1]=0;
			}


			if(arrB[i][j-1][2]!=0){
				NarrB[i][j-1][2]=arrB[i][j-1][2];
				NarrB[i][j-1][3]=arrB[i][j-1][3];
			}
			else{
				NarrB[i][j-1][2]=0;
				NarrB[i][j-1][3]=0;
			}
			NarrB[i][j-1][4]=0;
			NarrB[i][j-1][5]=0;
			NarrB[i][j-1][6]=0;
			NarrB[i][j-1][7]=0;
		   }
	   }

	   cout<<"======New B Table After Node 2 and 3 merged=========="<<endl;

	   int print_raw=0;
	   for(int node=0; node < 3; node++){
		   cout<<"Node: "<<node<<endl;
		for(int time_const=1; time_const < 7; time_const++){
			
				if(print_raw){
					printf("%4.2f,%i)(%4.2f,%i)(%4.2f,%i)(%4.2f,%i)|",NarrB[node][time_const-1][0],int(NarrB[node][time_const-1][1]),NarrB[node][time_const-1][2],int(NarrB[node][time_const-1][3]),
					NarrB[node][time_const-1][4],int(NarrB[node][time_const-1][5]),NarrB[node][time_const-1][6],int(NarrB[node][time_const-1][7]));
				}

				else{
				if(NarrB[node][time_const-1][0]!=0){
					printf("(%4.2f,%i)",NarrB[node][time_const-1][0],int(NarrB[node][time_const-1][1]));
				}
				else{
					cout<<" ";
				}
				if(NarrB[node][time_const-1][2 ]!=0){
					printf("(%4.2f,%i)",NarrB[node][time_const-1][2],int(NarrB[node][time_const-1][3]));
				}
				else{
					cout<<" ";
				}
				if(NarrB[node][time_const-1][4]!=0){
					printf("(%4.2f,%i)",NarrB[node][time_const-1][4],int(NarrB[node][time_const-1][5]));
				}
				else{
					cout<<" ";
				}
				if(NarrB[node][time_const-1][6]!=0){
					printf("(%4.2f,%i)",NarrB[node][time_const-1][6],int(NarrB[node][time_const-1][7]));
				}
				else{
					cout<<" ";
				}
				printf("|");
				//else{
					//printf("---");
					//printf("%4.2f,%i)(%4.2f,%i)(%4.2f,%i)(%4.2f,%i)|",NarrB[node][time_const-1][0],int(NarrB[node][time_const-1][1]),NarrB[node][time_const-1][2],int(NarrB[node][time_const-1][3]),
				    //NarrB[node][time_const-1][4],int(NarrB[node][time_const-1][5]),NarrB[node][time_const-1][6],int(NarrB[node][time_const-1][7]));
				//}
		}
				
		}
				cout<<endl;

	}
	}
	
		
	//Dtable============================================================================================
	float Darr[3][7][8];
	//initilizing global D Table array 
	for(int i=0; i<3; i++){
		for(int j=0; j<7; j++){
			for(int k=0; k<8; k++){
			
				Darr[i][j][k]=0.0;
			}
		}
	}



	//initilizing global Dtemp array //again bad code!!
	for(int i=0; i<2; i++){
		for(int j=0; j<7; j++){
			for(int k=0; k<32; k++){
			
				Dtemp[i][j][k]=0.0;
			}
		}
	}


	//first copy the first Node (Node 0)...........................
	//cout<<"===D table Debug====="<<endl;
	for(int i=0; i<1;i++){
		for(int j=1; j<7; j++){
			//cout<<"(";
			for(int k=0; k<8;k++){
				Darr[i][j-1][k]=NarrB[i][j-1][k];				
				//printf("%4.2f,",Darr[i][j-1][k]);				
			}
			//cout<<") |";
		}
		
	}



	//Genrating D table for rest of the Nodes (Node 1 and 3)---------------------
	int time;
	

	int p1,p2,index,Dtime=0;
	index =1;
	for(int i=1; i<2; i++){     // (!!!!Debug  only node 1) Processing Node 1 and 2 for rest of the timing constraint.  
		for(int j=1; j<7; j++){

			//--------------Making Dtemp all zero again----------------
			for(int i=0; i<2; i++){
				for(int j=0; j<7; j++){
					for(int k=0; k<32; k++){
			
						Dtemp[i][j][k]=0.0;
					}
				}
			}
			//----------------------------------------------------------
			time =j+1; //array index and time unit are not same!!!!!!!
 			p1=time-1;
			p2=1;
			int tval=0;
			Dtime=0;
			while(p1!=0){ 
				Dval(NarrB, 0 , 1, p1, p2,0,Dtime,j); //Dval(NarrB[][][],node1,node2,p1,p2,Dnode,Dtime)
				if(j==2){
					//"p1: "<<p1<<" P2: "<<p2<<" Dtime: "<<Dtime<<endl;
				}
				p2++;
				p1--;
				tval++;
				Dtime++;
			}  

			/*
			if(i==1 && j==1){
				Darr[1][1][0]=Dtemp[0][0][0];
				Darr[1][1][1]=Dtemp[0][0][1];
			}
			
			if(i==1 && j==2){
				Darr[1][2][0]=Dtemp[0][0][0];
				Darr[1][2][1]=Dtemp[0][0][1];
				Darr[1][2][2]=Dtemp[0][0][2];
				Darr[1][2][3]=Dtemp[0][0][3];
				Darr[1][2][4]=Dtemp[0][0][4];
				Darr[1][2][5]=Dtemp[0][0][5];
				Darr[1][2][6]=Dtemp[0][0][6];
			}
			*/
			if(0){
			cout<<"====Debug DTemp[0][0][1-32]========================"<<j<<endl; 

			for(int i=0; i<Dtime; i++){
				cout<<"Node: "<<i<<endl;
				for(int k=0; k<32 ; k++){
					if(Dtemp[0][i][k]){
						cout<<Dtemp[0][i][k]<<",";
					}
				}
				cout<<endl;
			}
			}


			int d_index=0;
			
		     
			
			for(int l=0; l<Dtime;l++){
				for(int m=0; m<4; m=m+2){
					float prob1=Dtemp[0][l][m];
					int   cost1=Dtemp[0][l][m+1];
					Darr[1][j][d_index]=prob1;
					Darr[1][j][d_index+1]=cost1;
					
					if(0){    //for debug
						cout<<"When t="<<j<<": "<<prob1<<","<<cost1<<endl;
					}
					if(prob1!=0){
						for(int r=0; r<Dtime; r++){
							for(int n=0; n<4; n=n+2){
								float prob2=Dtemp[0][r][n];
								int   cost2=Dtemp[0][r][n+1];
								if(prob2!=0){
									if((prob1==prob2) & (cost1==cost2)){
										//do nothing (skip)--bad code design, I know!!
									}
									else{
										a=checker(prob1,cost1,prob2,cost2);
							
										if(a==0){
											Darr[1][j][d_index]=0;//prob1;
											Darr[1][j][d_index+1]=0;//cost1;
											//d_index=d_index+2;
										}
								
							  
									}
								}
						}
					}
				}
					/*
					if(a){
						Darr[1][j-1][d_index]=prob1;
						Darr[1][j-1][d_index+1]=cost1;
						d_index=d_index+2;
					}
					*/
					d_index=d_index+2;
				
				
				}
			}


			/*
			int d_e=0;
			for (int time=0; time<Dtime+1; time++){

				float prob1=Dtemp[0][time][0];
				int cost1=Dtemp[0][time][1];
				
				for(int d=2; d<16; d =d+2){
					float prob2=Dtemp[0][time][d];
					int cost2=Dtemp[0][time][d+1];
					if(prob2!=0){
						a=checker(prob1,cost1,prob2,cost2);
						if(a){
							Darr[0][j-1][d_e]=prob1;
							Darr[0][j-1][d_e+1]=cost1;
							d_e=d_e+2
							//prob1=Dtemp[0][time][d];
							//cost1=Dtemp[0][time][d+1];
						}
						else {
							//Dtemp[0][time][d-2]=0;
							//Dtemp[0][time][d-1]=0;
						}
					}
				}
				time++;
			}
		    */
		}
	}


	cout<<"===============D table==============="<<endl;
	for(int k=0; k<8; k++){   //At T=0 Node 1 will not execute and Node 2 will execute for T=0 and 1
		Darr[1][0][k]=0;
		Darr[2][0][k]=0;
		Darr[2][1][k]=0;
	}

	for(int i=0; i<2;i++){
		cout<<"Node:"<<i<<endl;
		for(int j=1;j<7;j++){
			for(int k=0; k<8; k=k+2){
				if(i==1 && j==1){
					cout<<"-- ";
				}
				if(Darr[i][j-1][k] && Darr[i][j-1][k+1]  >0){
					cout<<"("<<Darr[i][j-1][k]<<","<<Darr[i][j-1][k+1]<<")";
				}
			}
			cout<<"||";
		}
		cout<<endl;
	}

	if(0){
		cout<<endl<<"====For D Table Debug======================"<<endl;
		for(int i=0; i<2; i++){
			cout<<"Node: "<<i<<endl;
			for(int j=0; j<7; j++){
				for(int k=0; k<8; k++){
					cout<<Darr[i][j][k]<<",";
				}
				cout<<"||";
			}
			cout<<endl;
		}
	}


	cin.get(); //So that this damn thing stops...
}



